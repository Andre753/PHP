<!DOCTYPE html>
<html>
  <head>
      <meta charset="utf-8" http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  </head>
<body>

  <?php
      //koneksi ke mysql
      $conn = mysqli_connect("localhost", "root", "", "persediaandb");

    if (mysqli_connect_errno()) {
    echo "Koneksi Gagal".mysqli_connect_errno();
    }

    $queryBarang = mysqli_query($conn, "select * from barang");
    $queryCustomer = mysqli_query($conn, "select * from customer");
  ?>

<CENTER>
<table width="300" height="150" border="1" bgcolor="#00FF99">
  <tr>
    <td><table width="200" height="10" >
    </tr> <center>
<h4>PT.SISTEM INFORMASI</h4>
<b>JL.Raya Serang Km.10 Bitung-Tangerang</b>

<hr>
 <center>
<table width="378" border="1" bgcolor="silver">
  <tr> 
    <td colspan="2"><center>INPUT DATA TRANSAKSI</center></td>
  </tr> 
<form method="post" action="koneksitransaksi.php">
</table>

<table width="300" height="150" border="1" bgcolor="silver">
<tr>
    <td width="175">Kode Transaksi</td>
    <td><input name="txtkdtransaksi" type="text" id="txtkdtransaksi" size="5" /></td>
  </tr>

                <tr>
                    <td>Kode Customer</td>
                    <td width="306">
                      <select name="cbcustomer" id="cbcustomer">
                        <?php
                        while ($row = mysqli_fetch_array($queryCustomer)) {
                          echo "<option value=".$row["kdcustomer"].">".$row["kdcustomer"]."</option>";
                        }
                        ?>
                      </select>
                    </td>
                  </tr>

                <tr>
                    <td>Kode Barang</td>
                    <td width="306">
                      <select name="cbbarang" id="cbbarang">
                        <?php
                        while ($row = mysqli_fetch_array($queryBarang)) {
                          echo "<option value=".$row["kdbarang"].">".$row["kdbarang"]."</option>";
                        }
                        ?>
                      </select>
                    </td>
                  </tr>

  <tr>
    <td>Quantity </td>
    <td><input name="txtquantity" type="text" id="txtquantity" size="15" /></td>
  </tr>

  <tr>
    <td>Tanggal </td>
    <td><input name="txttanggal" type="text" id="txttanggal" size="40" /></td>
  </tr>

  <tr> <center>
    <td colspan="2"><form id="form5" name="form5" method="post" action="">
      <input name="BtnSave" type="submit" id="BtnSave" value="Save" />
        <input name="BtnBatal" type="reset" id="BtnBatal" value="Batal" />
    </form>    
  </td>
</center>
</tr>

</table> </center><p>
<br>
<center>
      <div class="Frame_Footer">
        <div class="Frame_Inside_Footer" style="background-color: #800000; color: #FFFFFF;">
          <span class="style1" style="color: #FFFFFF">Copyrights by Andre Stefanus</span>
          <br class="style1"/>
          <span class="style1">
            <span class="style1">
              &copy; 2023 All Rights Reserved
            </span>
          </span>
        </div>
      </div>
    </center>
  </body>
</html>
</table>
</form>