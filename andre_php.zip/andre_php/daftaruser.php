<html>
<title>
	Daftar User
</title>


<body>
	<?php
	$conn = mysqli_connect("localhost","root","","persediaandb");
	    if (mysqli_connect_errno())
		{
			echo "Koneksi Gagal".mysqli_connect_error();
		}

		$query = mysqli_query($conn,"select * from user");

	?>
	<table width="100%" height="100%" border="1" bgcolor="skyblue">
		<tr>
			<td>
				<table width="600" height="80" border="1" align="center" bgcolor="red">
				<center>
					<tr>
						<td width="400"><center><h1>DAFTAR USER</h1></center>
						</td>
					</tr>
					<form method="post" action="koneksiuser.php">
				</table>
	<table width="600" border="1" align="center" bgcolor="white">
	<tr>
	<td>username</td>
	<td>password</td>
	<td>Hapus</td>
	<td>Edit</td>
	<td>Kembali</td>

</tr>

    <?php
    while($row=mysqli_fetch_array($query))
{
	echo"<tr>";
	echo"<td>".$row["username"]."</td>";
	echo"<td>".$row["password"]."</td>";
	echo"<td><a href =deleteuser.php?username=".$row["username"].">Delete</a></td>";
	echo"<td><a href =edituser.php?username=".$row["username"].">Edit</a></td>";
	echo"<td><a href ='user.php'>Back</a></td>";
	echo"</tr>";

}
?>
</table>
</table>
</center>
<center>
	<div class="Frame_Footer">
    <div class="Frame_Inside_Footer" style="background-color: blue; color: white">
	<span class="style1" style="color:white">Copyright by Andre Stefanus</span><br class="style1" />
	<span class="style1"><span class="style1">&copy;2023 All Rights Reserved</span></span><span class="style1"></span>
    </div>
</center>
</body>
</html>