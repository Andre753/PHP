<html>
<body>
		<?php  
			// Koneksi ke mysql
			$conn = mysqli_connect("localhost", "root", "", "persediaandb");

			if (mysqli_connect_errno()) {
				echo "Koneksi Gagal".mysqli_connect_error();
			}
			$kdbarang= $_GET['kdbarang'];
			$query= mysqli_query($conn,"delete from barang where kdbarang='$kdbarang'") or die (mysql_error());
		?>

		data sudah di hapus
		<a href = "daftarbarang.php">lihat data </a>
</body>
</html>