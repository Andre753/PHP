
<html>
<body>
		<?php  
			// Koneksi ke mysql
			$conn = mysqli_connect("localhost", "root", "", "persediaandb");

			if (mysqli_connect_errno()) {
				echo "Koneksi Gagal".mysqli_connect_error();
			}
			$query = mysqli_query($conn, "select * from barang where kdbarang='$_GET[kdbarang]'");
			$row=mysqli_fetch_array($query);
		?>

		<center>
			<table width="1350" height="500" border="1" bgcolor="#00FF99">
				<tr>
					<td>
						<center>
							<table width="300" height="47" border="1" align="center" bgcolor="yellow">
								<tr>
									<td width="300"><center>INPUT DATA BARANG</center></td>
								</tr>
							</table>

		<table width="300" border="1" bgcolor="silver">
		<form action="editproses.php"method="post">

					<tr>
					<td width="175">Kdbarang: </td>
					<td><input type="text"name="kdbarang"value="<?php echo $row['kdbarang'];?>"></td>
					</tr>

					<tr>
					<td>Nmbarang: </td>
					<td><input type="text"name="nmbarang"value="<?php echo $row['nmbarang'];?>"></td>
				    </tr>

				    <tr>
					<td>Satuan: </td>
					<td><select name="satuan"value="<?php echo $row['satuan'];?>">
					    <option value="Pcs">Pcs</option>
					    <option value="Set">Set</option>
					    <option value="Box">Box</option>
					    <option value="Kg">Kg</option>
					    </select>
					</td>
				    </tr>

				    <tr>
					<td>Warna: </td>
					<td><select name="warna"value="<?php echo $row['warna'];?>">
					     <option value="Hitam">Hitam</option>
					     <option value="Biru">Biru</option>
					     <option value="Putih">Putih</option>
					     <option value="None">None</option>
						 </select>
					</td>
				    </tr>

				    <tr>
					<td>Jumlah: </td>
					<td><input type="text"name="jumlah"value="<?php echo $row['jumlah'];?>"></td>
				    </tr>

				    <tr>
					<td colspan="2"><input type="submit"value="Update"/></td>
				    </tr>
				</form>

			</table>
		    </table>
		   </center>
			<center>
			<div class="Frame_Footer">
				<div class="Frame_Inside_Footer" style="background-color: #800000; color: #FFFFFF;">
					<span class="style1" style="color: #FFFFFF">Copyrights by Andre Stefanus</span>
					<br class="style1"/>
					<span class="style1">
						<span class="style1">
							&copy; 2023 All Rights Reserved
						</span>
					</span>
				</div>
			</div>
		</center>

</body>
</html>