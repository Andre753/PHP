<?php
	// Koneksi ke mysql
	$conn = mysqli_connect("localhost", "root", "", "persediaandb");

	if (mysqli_connect_errno()) {
		echo "Koneksi Gagal".mysqli_connect_errno();
	}

	{
		$vkdtransaksi = $_POST['txtkdtransaksi'];
		$vcbcustomer = $_POST['cbcustomer'];
		$vcbbarang = $_POST['cbbarang'];
		$vquantity = $_POST['txtquantity'];
		$vtanggal = $_POST['txttanggal'];
		{
			$query = mysqli_query($conn, "insert into transaksi(kdtransaksi, kdcustomer, kdbarang, quantity, tanggal) values('$vkdtransaksi', '$vcbcustomer', '$vcbbarang', '$vquantity', '$vtanggal')");
			
			if ($query)
				echo "Input Data Sukses<br>";
			else
				echo "Input Data Gagal<br>";
		}
	//header("location:transaksi.php");
	}
?>