<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Data User</title>
<style type="text/css">
<!--
.Style1 {color: #F3F3F3}
-->
</style>
</head>

<body>
<CENTER>
<table width="300" height="150" border="1" bgcolor="silver">
  <tr>
    <td><table width="200" height="10" >
    </tr> <center>
<h4>PT.SISTEM INFORMASI</h4>
<b>JL.Raya Serang Km.10 Bitung-Tangerang</b>

<hr>
 <center>
<table width="322" border="1" bgcolor="#00FF00">
  <tr> 
    <td colspan="2">INPUT DATA USER </td>
  </tr> 
<form method="post" action="koneksiuser.php">

  <tr>
    <td width="175">Username</td>
    <td><input name="txtusername" type="text" id="txtusername" size="20" /></td>
  </tr>

  <tr>
    <td>Password </td>
    <td><input name="txtpass" type="text" id="txtpass" size="20" /></td>
  </tr>

  

  <tr> <center>
    <td colspan="2"><form id="form5" name="form5" method="post" action="">
      <input name="BtnSave" type="submit" id="BtnSave" value="Save" />
        <input name="BtnBatal" type="reset" id="BtnBatal" value="Batal" />
    </form>    </td></center>
  </tr>

</table> </center><p>
<br>
<center>
      <div class="Frame_Footer">
        <div class="Frame_Inside_Footer" style="background-color: #800000; color: #FFFFFF;">
          <span class="style1" style="color: #FFFFFF">Copyrights by Andre Stefanus</span>
          <br class="style1"/>
          <span class="style1">
            <span class="style1">
              &copy; 2023 All Rights Reserved
            </span>
          </span>
        </div>
      </div>
    </center>
  </body>
</html>
</table>
</form>
