<!DOCTYPE html>
<html>
<head>
	<title>Sistem Persediaan </title><center>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<center>
	<table width="950" height="200" border="1" background="1.png" bgcolor="#00ff99">
		<tr>
			<td><table width="200" height="450">
		<center></tr>
	<h2>SELAMAT DATA DI SISTEM INFORMASI PERSEDIAAN </h2>
</center>
<hr>
<p align="center"</p>
<div class="Menu">
<ul id="navigasi">
	<li><a href="2.PNG">Home</a></li>
	<li><a href="#">About</a>
<ul>
	<li><a href="">Sejarah</a></li>
	<li><a href="">Visi</a></li>
	<li><a href="#">Struktur Organisasi</a></li>
</ul>
</li>
<li><a href="#">Master Data </a>
	<ul>
		<li><a href="barang.php">Data barang</a></li>
		<li><a href="customer.php">Data Customer</a></li>
		<li><a href="user.php">Data User</a></li>
	</ul>

<li><a href="transaksi.php">Transaksi</a></li>
<ul>
	<li><a href="">Persediaan Barang</a></li>
</ul>
<li><a href="#">Perubahan Data</a>
<ul>
	<li><a href="daftarbarang.php">Edit Data Barang</a></li>
	<li><a href="daftaruser.php">Edit Data User</a></li>
	<li><a href="">Edit Data Persediaan</a></li>
</ul>
</li>

<li><a href="#">Laporan</a>
<ul>
	<li><a href="laporandatabarang.php">Laporan Data Barang</a></li>
	<li><a href="">Laporan Data Customer</a></li>
	<li><a href="">Laporan Persediaan Barang</a></li>
</ul>
</li>

<li><a href="2.jpg">Galery</a>
<li><a href="">Contact</a>
<li><a href="index.php">Logout</a>
<li><a href="#">Registration</a>
</ul></hr>
<center>

</td>
</tr>
</table>

<center>
			<div class="Frame_Footer">
				<div class="Frame_Inside_Footer" style="background-color: #800000; color: #FFFFFF;">
					<span class="style1" style="color: #FFFFFF">Copyrights by Andre Stefanus</span>
					<br class="style1"/>
					<span class="style1">
						<span class="style1">
							&copy; 2023 All Rights Reserved
						</span>
					</span>
				</div>
			</div>
		</center>
	</body>
</html>